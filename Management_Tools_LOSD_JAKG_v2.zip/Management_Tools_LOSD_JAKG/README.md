# Management Tools LOSD JAKG

Aplikasi Streamlit untuk inventaris tools, data peminjam, transaksi peminjaman/pengembalian, riwayat, dan laporan.

## Menjalankan aplikasi

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Menghubungkan Google Spreadsheet

1. Buat/siapkan Google Spreadsheet untuk database.
2. Buat Google Cloud service account dan aktifkan Google Sheets API serta Google Drive API.
3. Unduh file JSON key service account.
4. Bagikan Spreadsheet kepada alamat email `client_email` di JSON service account sebagai **Editor**.
5. Buat folder `.streamlit`, lalu buat file `.streamlit/secrets.toml` berdasarkan contoh di bawah.
6. Isi `id` dengan ID Spreadsheet (bagian di antara `/d/` dan `/edit` pada URL).

Contoh `.streamlit/secrets.toml`:

```toml
[spreadsheet]
id = "ISI_ID_SPREADSHEET_DI_SINI"

[gcp_service_account]
type = "service_account"
project_id = "PROJECT_ID"
private_key_id = "PRIVATE_KEY_ID"
private_key = """-----BEGIN PRIVATE KEY-----
ISI_PRIVATE_KEY
-----END PRIVATE KEY-----
"""
client_email = "nama-service-account@project-id.iam.gserviceaccount.com"
client_id = "CLIENT_ID"
token_uri = "https://oauth2.googleapis.com/token"
```

Tambahkan juga field JSON service account lainnya jika tersedia (misalnya `auth_uri`, `auth_provider_x509_cert_url`, `client_x509_cert_url`, `universe_domain`).

## Tab/worksheet yang digunakan

Aplikasi akan membuat tab berikut secara otomatis bila belum ada:
- `Tools`: Nama Alat, Kode, Stok
- `Peminjam`: Nama Peminjam, NIPP, Bagian
- `Peminjaman`: ID Transaksi, Nama Peminjam, NIPP, Nama Alat, Kode Alat, Jumlah, Tanggal Pinjam, Tanggal Kembali, Status

**Penting:** Untuk keamanan, jangan mengunggah atau mengirim file JSON service account/private key ke chat. Masukkan rahasia tersebut hanya ke `secrets.toml` di komputer atau pengaturan Secrets pada layanan hosting.

## Catatan migrasi

Aplikasi memiliki fallback CSV lokal ketika konfigurasi Google Spreadsheet belum dipasang. Data lokal tidak otomatis digabungkan ke Spreadsheet. Sebelum pemakaian operasional, siapkan tab database dan lakukan uji peminjaman/pengembalian dengan data percobaan.
